package com.mobiquityinc.packer;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Test;

import com.mobiquityinc.model.Item;

public class PackerTest{
	
    @Test
	public void testknapsackProblem() {
		
    	List<Item> lstItem = new ArrayList<>();
    	
    	prepareData(lstItem,1,53.38,45);
    	prepareData(lstItem,2,88.62,98);
    	prepareData(lstItem,3,78.48,3);
    	prepareData(lstItem,4,72.30,76);
    	prepareData(lstItem,5,30.18,9);
    	prepareData(lstItem,6,46.34,48);
    	assertEquals("4", Packer.knapsackProblem(lstItem, 81));
		lstItem.clear();
		prepareData(lstItem,1,15.3,34);
		assertEquals("-", Packer.knapsackProblem(lstItem, 8));
		
		
		lstItem.clear();
		prepareData(lstItem,1,85.31,29);
		prepareData(lstItem,2,14.55,74);
		prepareData(lstItem,3,3.98,16);
		prepareData(lstItem,4,26.24,55);
		prepareData(lstItem,5,63.69,52);
		prepareData(lstItem,6,76.25,75);
		prepareData(lstItem,7,60.02,74);
		prepareData(lstItem,8,93.18,35);
		prepareData(lstItem,9,89.95,78);
		assertEquals("2,7", Packer.knapsackProblem(lstItem, 75));
		lstItem.clear();
		prepareData(lstItem,1,90.72,13);
		prepareData(lstItem,2,33.80,40);
		prepareData(lstItem,3,43.15,10);
		prepareData(lstItem,4,37.97,16);
		prepareData(lstItem,5,46.81,36);
		prepareData(lstItem,6,48.77,79);
		prepareData(lstItem,7,81.80,45);
		prepareData(lstItem,8,19.36,79);
		prepareData(lstItem,9,6.76,64);
		
		assertEquals("8,9", Packer.knapsackProblem(lstItem, 56));
	}
    private void prepareData(List<Item> lstItem, int index,double weight,int cost) {
    	Item item = new Item(index,weight,cost);
    	lstItem.add(item);
		
    }

}
