package com.mobiquityinc.packer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.mobiquityinc.exception.APIException;
import com.mobiquityinc.model.Item;

public class Packer {

  private Packer() {
  }
  
  public static String pack(String filePath) throws APIException {
	 StringBuilder strResult = new StringBuilder();
	 // Map a row with key: Capicity: values: List Items
	  Map<String, List<Item>> mapData = new LinkedHashMap<String, List<Item>>();
	  	try {
		File fileDir = new File(filePath);
		if(fileDir.exists()) {
			// Open file Utf-8 and read by line 
			BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(fileDir), "UTF-8"));
			String line = reader.readLine();
			List<Item> lstItem;
			while( null != line) {
				//read line
				if(line != null) {
					parse(line, mapData);
				}
				
				line = reader.readLine();
				
			} 
			reader.close();
			for (String key: mapData.keySet()){
		           
	            lstItem = mapData.get(key);
	            strResult.append(knapsackProblem(lstItem,Integer.parseInt(key.trim())));
	            strResult.append("\n");
			} 
		}
	  	}catch(IOException ioe) {
	  		throw new APIException("File not found",ioe);
	  	}
	  	
	return strResult.toString();
  }
  /**
   * Parse row data into Item POJO
   * @param str : row data
   * @param m : Map contents key:Max capicity, values : Items
   * @throws APIException
   */
  private static void parse(String str ,Map<String,List<Item>> m) throws APIException {
	  // check data validate
	  if(!str.matches("\\d+\\s*:(\\s*\\(\\d+,\\d+\\.*\\d+,�\\d+\\))+")) {
			throw new APIException("Invalid data input");
		}
		List<Item> finallist =new ArrayList<Item>();
		try {
		String[] kv = str.split(":");
		List<String> itemlist = Arrays.asList((String[])kv[1].split(" "));
		List<String> rawitem =  itemlist.stream().map( s-> s.replace("(", "").replace(")", "").replace("�", "")).collect(Collectors.toList());
		// parse data and put it in List Items
		for(String x : rawitem) {
			if(x.equals("")) {
				continue;
			}
			//System.out.println(x);
			String[]attributeStrings =x.split(",");
			if(Double.parseDouble(attributeStrings[1])<100 && Integer.parseInt(attributeStrings[2])<100) {
			Item item = new Item(Integer.parseInt(attributeStrings[0]),Double.parseDouble(attributeStrings[1]),Integer.parseInt(attributeStrings[2]));
			finallist.add(item);
			
			}
			else {
				continue;
			}
		
		}
	   m.put(kv[0], finallist);
	  }
		catch (Exception e) {
			throw new APIException("Invalid data", e);
		}
	   
	}
  /**
   * Algorithm Bin package
   * @param lstItem : the list of packages
   * @param maxWeight : bin capacity
   * @return String index
   */
  public static String  knapsackProblem(List<Item> lstItem,int maxWeight) {
	  StringBuilder strIndex = new StringBuilder();
	  // order by follow weight
	  Collections.sort(lstItem);
	  int size = lstItem.size();
	  double weight;
	  int cost;
	  if(size > 0) {
		  List<String> lstOrderIndex = new ArrayList<String>();
		  int[][] f= new int[size+1][maxWeight+1];
		  // f[0][j] ==0
		  for (int j = 0; j <= maxWeight; ++j) {
			  f[0][j] = 0;
		  }
		  for (int i = 1; i <= size; ++i) {
		    for (int j  = 1; j <= maxWeight; ++j) {
		      f[i][j] = f[i-1][j];
		     
		      weight = lstItem.get(i-1).getWeight();
		      if (weight <= j) {
		    	  // if weight[i] <= j then
		    	  //f[i][j]=max(f[i-1][j],cost[i]+f[i][j-w[i]])
		      	  cost = lstItem.get(i-1).getCost();	    	  
		    	  f[i][j] = Math.max(f[i][j], f[i-1][(int)Math.ceil(j-weight)] + cost);
		    	    
		    	
		      }
		      
		    }
		  }
		  //
		  int j = maxWeight;
		  // tracing data to get index 
		  for (int i = size;  i > 0; --i) {
			  if (f[i][j] == f[i-1][j]) continue;
			  if(strIndex.length() > 0) {				  
				   strIndex.insert(0,",");				   
			  }
		   
		   lstOrderIndex.add(lstItem.get(i-1).getIndex()+"");
		   j =j- (int)lstItem.get(i-1).getWeight();
		  }
		  // order by index
		  if(lstOrderIndex.size() == 0) {
			  strIndex.append("-");
		  } else {
			  Collections.sort(lstOrderIndex);
			  strIndex.append(String.join(",",lstOrderIndex));
		  }
	  } else {
		  strIndex.append("-");
	  }
	  return strIndex.toString();
  } 
}
