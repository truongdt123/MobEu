package com.mobiquityinc.model;
/**
 * 
 * @author john.doan
 * The class is POJO of Item
 * weight: weight of package
 * cost : cost for package sending
 * index: ordering of package
 *
 */
public class Item implements Comparable<Item>{
	/**
	 * 
	 */
	private double weight;
	private int cost;
	private int index;
	public Item(int index,double weight,int cost) {
		this.index = index;
		this.weight = weight;
		this.cost = cost;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	@Override
    public int compareTo(Item o) 
    {
        return (int)(this.getWeight() - o.getWeight());
    }
}
