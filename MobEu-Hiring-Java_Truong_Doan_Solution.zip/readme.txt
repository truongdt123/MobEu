- build project : mvn clean install.
- output: target/implementation-1.0-SNAPSHOT.jar.
- input sample : pakage.txt
- usage: 
 1. import jar
 2. code:
 
   try {
		Packer.pack(pathFile);
		}catch(APIException api) {
			
	}